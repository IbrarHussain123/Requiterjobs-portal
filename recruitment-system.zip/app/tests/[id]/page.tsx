"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, Clock, Camera, ArrowLeft } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import Link from "next/link"

// Sample test data
const testData = {
  id: 1,
  title: "Frontend Developer Screening Test",
  company: "TechCorp Inc.",
  duration: 45, // in minutes
  totalQuestions: 20,
  instructions:
    "This test evaluates your knowledge of frontend development concepts, including HTML, CSS, JavaScript, and React. Please answer all questions to the best of your ability. You cannot pause or restart the test once it begins.",
  questions: [
    {
      id: 1,
      question: "Which of the following is NOT a JavaScript data type?",
      options: ["String", "Boolean", "Float", "Symbol"],
      correctAnswer: 2, // Index of the correct answer
    },
    {
      id: 2,
      question: "What does CSS stand for?",
      options: ["Creative Style Sheets", "Cascading Style Sheets", "Computer Style Sheets", "Colorful Style Sheets"],
      correctAnswer: 1,
    },
    {
      id: 3,
      question: "Which HTML tag is used to define an internal style sheet?",
      options: ["<css>", "<script>", "<style>", "<link>"],
      correctAnswer: 2,
    },
    {
      id: 4,
      question: "In React, what is used to pass data to a component from outside?",
      options: ["setState", "render with arguments", "props", "PropTypes"],
      correctAnswer: 2,
    },
    {
      id: 5,
      question: "Which of the following is a hook in React?",
      options: ["useState", "useFetch", "useComponent", "useData"],
      correctAnswer: 0,
    },
    // More questions would be added here in a real application
  ],
}

export default function TestPage({ params }: { params: { id: string } }) {
  const [started, setStarted] = useState(false)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<(number | null)[]>(Array(testData.questions.length).fill(null))
  const [timeLeft, setTimeLeft] = useState(testData.duration * 60) // in seconds
  const [showWarning, setShowWarning] = useState(false)
  const [captureCount, setCaptureCount] = useState(0)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [cameraActive, setCameraActive] = useState(false)

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  // Start the test timer
  useEffect(() => {
    if (!started) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0) {
          clearInterval(timer)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [started])

  // Periodic screenshot capture for verification
  useEffect(() => {
    if (!started || !cameraActive) return

    // Capture screenshot every 30 seconds
    const captureInterval = setInterval(() => {
      captureScreenshot()
      setCaptureCount((prev) => prev + 1)
    }, 30000)

    return () => clearInterval(captureInterval)
  }, [started, cameraActive])

  // Initialize camera
  const startCamera = async () => {
    try {
      if (videoRef.current) {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true })
        videoRef.current.srcObject = stream
        setCameraActive(true)
      }
    } catch (err) {
      console.error("Error accessing camera:", err)
      setShowWarning(true)
    }
  }

  // Capture screenshot for verification
  const captureScreenshot = () => {
    if (videoRef.current && canvasRef.current && cameraActive) {
      const context = canvasRef.current.getContext("2d")
      if (context) {
        context.drawImage(videoRef.current, 0, 0, canvasRef.current.width, canvasRef.current.height)
        // In a real application, this would be sent to the server for verification
        console.log("Screenshot captured for verification")
      }
    }
  }

  // Start the test
  const handleStartTest = async () => {
    await startCamera()
    setStarted(true)
  }

  // Handle answer selection
  const handleAnswerSelect = (value: string) => {
    const newAnswers = [...answers]
    newAnswers[currentQuestion] = Number.parseInt(value)
    setAnswers(newAnswers)
  }

  // Navigate to next question
  const handleNextQuestion = () => {
    if (currentQuestion < testData.questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1)
    }
  }

  // Navigate to previous question
  const handlePrevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion((prev) => prev - 1)
    }
  }

  // Submit the test
  const handleSubmitTest = () => {
    // In a real application, this would send the answers to the server
    console.log("Test submitted:", answers)
    // Redirect to results page
    window.location.href = `/tests/${params.id}/results`
  }

  // Calculate progress percentage
  const progress = ((currentQuestion + 1) / testData.questions.length) * 100

  // Calculate answered questions count
  const answeredCount = answers.filter((a) => a !== null).length

  return (
    <div className="container mx-auto px-4 py-8">
      {!started ? (
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl">{testData.title}</CardTitle>
            <CardDescription>
              <span className="font-medium">{testData.company}</span> • Duration: {testData.duration} minutes •{" "}
              {testData.totalQuestions} questions
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-medium mb-2">Test Instructions:</h3>
              <p className="text-muted-foreground">{testData.instructions}</p>
            </div>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Important</AlertTitle>
              <AlertDescription>
                This test requires camera access for identity verification. Periodic screenshots will be taken during
                the test to ensure test integrity. Please ensure you are in a well-lit environment and your face is
                clearly visible.
              </AlertDescription>
            </Alert>

            <div className="rounded-lg border p-4">
              <h3 className="font-medium mb-2">Before you begin:</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Ensure you have a stable internet connection</li>
                <li>Allow camera access when prompted</li>
                <li>You cannot pause or restart the test once it begins</li>
                <li>The test will automatically submit when the time expires</li>
                <li>Ensure you are in a quiet environment with no distractions</li>
              </ul>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" asChild>
              <Link href="/candidate/dashboard">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Return to Dashboard
              </Link>
            </Button>
            <Button onClick={handleStartTest}>Start Test</Button>
          </CardFooter>
        </Card>
      ) : (
        <div className="max-w-3xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold">{testData.title}</h1>
              <p className="text-muted-foreground">{testData.company}</p>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {formatTime(timeLeft)}
              </Badge>
              <Badge variant="outline">
                Question {currentQuestion + 1} of {testData.questions.length}
              </Badge>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <Card>
                <CardHeader>
                  <Progress value={progress} className="mb-2" />
                  <CardTitle className="text-lg">Question {currentQuestion + 1}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="mb-4">{testData.questions[currentQuestion].question}</p>
                  <RadioGroup value={answers[currentQuestion]?.toString() || ""} onValueChange={handleAnswerSelect}>
                    {testData.questions[currentQuestion].options.map((option, index) => (
                      <div key={index} className="flex items-center space-x-2 mb-3">
                        <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                        <Label htmlFor={`option-${index}`}>{option}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={handlePrevQuestion} disabled={currentQuestion === 0}>
                    Previous
                  </Button>
                  {currentQuestion < testData.questions.length - 1 ? (
                    <Button onClick={handleNextQuestion}>Next</Button>
                  ) : (
                    <Button onClick={handleSubmitTest}>Submit Test</Button>
                  )}
                </CardFooter>
              </Card>
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Verification Camera</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative rounded-md overflow-hidden bg-muted aspect-video mb-2">
                    {cameraActive ? (
                      <video ref={videoRef} autoPlay muted className="w-full h-full object-cover" />
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <Camera className="h-8 w-8 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  <canvas ref={canvasRef} className="hidden" width="320" height="240" />
                  {showWarning && (
                    <Alert variant="destructive" className="mt-2">
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Camera Error</AlertTitle>
                      <AlertDescription>
                        Unable to access camera. Please ensure you've granted camera permissions.
                      </AlertDescription>
                    </Alert>
                  )}
                  <p className="text-xs text-muted-foreground mt-2">
                    Screenshots: {captureCount} captured for verification
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Question Navigator</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-5 gap-2">
                    {answers.map((answer, index) => (
                      <Button
                        key={index}
                        variant={currentQuestion === index ? "default" : answer !== null ? "outline" : "ghost"}
                        className={`h-10 w-10 p-0 ${answer !== null ? "border-green-500" : ""}`}
                        onClick={() => setCurrentQuestion(index)}
                      >
                        {index + 1}
                      </Button>
                    ))}
                  </div>
                  <Separator className="my-4" />
                  <div className="flex justify-between text-sm">
                    <span>
                      Answered: {answeredCount}/{testData.questions.length}
                    </span>
                    <span>Remaining: {testData.questions.length - answeredCount}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

