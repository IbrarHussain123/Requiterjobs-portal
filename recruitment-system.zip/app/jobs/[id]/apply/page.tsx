"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Upload, Building, MapPin, Briefcase, Clock, Calendar } from "lucide-react"
import Link from "next/link"

// Sample job data
const jobData = {
  id: 1,
  title: "Frontend Developer",
  company: "TechCorp Inc.",
  location: "Remote",
  type: "Full-time",
  salary: "$80,000 - $100,000",
  postedDate: "2023-10-15",
  deadline: "2023-11-15",
  description:
    "We are looking for a skilled Frontend Developer to join our team. The ideal candidate should have experience with React, TypeScript, and modern CSS frameworks.",
  requirements: [
    "3+ years of experience in frontend development",
    "Strong proficiency in JavaScript, HTML, and CSS",
    "Experience with React and TypeScript",
    "Familiarity with modern frontend build tools",
    "Understanding of responsive design principles",
    "Experience with version control systems (Git)",
    "Good problem-solving skills and attention to detail",
    "Excellent communication and teamwork skills",
  ],
  benefits: [
    "Competitive salary and benefits package",
    "Remote work flexibility",
    "Professional development opportunities",
    "Health, dental, and vision insurance",
    "401(k) matching",
    "Paid time off and holidays",
    "Modern equipment and tools",
  ],
}

export default function ApplyJobPage({ params }: { params: { id: string } }) {
  const [activeTab, setActiveTab] = useState("personal")
  const [profileImage, setProfileImage] = useState<string | null>(null)

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        setProfileImage(event.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-8">
        <Button variant="ghost" size="sm" className="mr-2" asChild>
          <Link href={`/jobs/${params.id}`}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Job Details
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Apply for {jobData.title}</CardTitle>
              <CardDescription>Complete all sections to submit your application</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="personal" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                <TabsList className="grid grid-cols-3 w-full">
                  <TabsTrigger value="personal">Personal Info</TabsTrigger>
                  <TabsTrigger value="experience">Experience</TabsTrigger>
                  <TabsTrigger value="documents">Documents</TabsTrigger>
                </TabsList>

                <TabsContent value="personal" className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="profile-image">Profile Picture (Required for Verification)</Label>
                    <div className="flex items-center gap-4">
                      <div className="h-24 w-24 rounded-full border overflow-hidden flex items-center justify-center bg-muted">
                        {profileImage ? (
                          <img
                            src={profileImage || "/placeholder.svg"}
                            alt="Profile"
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <Upload className="h-8 w-8 text-muted-foreground" />
                        )}
                      </div>
                      <Input id="profile-image" type="file" accept="image/*" onChange={handleImageUpload} />
                    </div>
                    <p className="text-xs text-muted-foreground">
                      This photo will be used for identity verification during the screening test.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="first-name">First Name</Label>
                      <Input id="first-name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="last-name">Last Name</Label>
                      <Input id="last-name" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone</Label>
                      <Input id="phone" type="tel" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Address</Label>
                    <Input id="address" />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="city">City</Label>
                      <Input id="city" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="state">State</Label>
                      <Input id="state" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="zip">ZIP Code</Label>
                      <Input id="zip" />
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button onClick={() => setActiveTab("experience")}>Next: Experience</Button>
                  </div>
                </TabsContent>

                <TabsContent value="experience" className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="education">Education</Label>
                    <Textarea
                      id="education"
                      placeholder="List your educational background, including degrees, institutions, and graduation dates."
                      className="min-h-[100px]"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="work-experience">Work Experience</Label>
                    <Textarea
                      id="work-experience"
                      placeholder="Describe your relevant work experience, including job titles, companies, dates, and responsibilities."
                      className="min-h-[150px]"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="skills">Skills</Label>
                    <Textarea
                      id="skills"
                      placeholder="List your technical and soft skills relevant to this position."
                      className="min-h-[100px]"
                    />
                  </div>

                  <div className="flex justify-between">
                    <Button variant="outline" onClick={() => setActiveTab("personal")}>
                      Back: Personal Info
                    </Button>
                    <Button onClick={() => setActiveTab("documents")}>Next: Documents</Button>
                  </div>
                </TabsContent>

                <TabsContent value="documents" className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="resume">Resume/CV</Label>
                    <Input id="resume" type="file" accept=".pdf,.doc,.docx" />
                    <p className="text-xs text-muted-foreground">
                      Accepted formats: PDF, DOC, DOCX. Maximum size: 5MB.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cover-letter">Cover Letter (Optional)</Label>
                    <Input id="cover-letter" type="file" accept=".pdf,.doc,.docx" />
                    <p className="text-xs text-muted-foreground">
                      Accepted formats: PDF, DOC, DOCX. Maximum size: 2MB.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="portfolio">Portfolio or Work Samples (Optional)</Label>
                    <Input id="portfolio" type="file" accept=".pdf,.zip,.rar" multiple />
                    <p className="text-xs text-muted-foreground">
                      Accepted formats: PDF, ZIP, RAR. Maximum size: 10MB.
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="additional-info">Additional Information</Label>
                    <Textarea
                      id="additional-info"
                      placeholder="Any additional information you'd like to share with the hiring team."
                      className="min-h-[100px]"
                    />
                  </div>

                  <div className="flex justify-between">
                    <Button variant="outline" onClick={() => setActiveTab("experience")}>
                      Back: Experience
                    </Button>
                    <Button>Submit Application</Button>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Job Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="text-xl font-bold">{jobData.title}</h3>
                <div className="flex flex-wrap items-center gap-3 mt-2 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Building className="h-4 w-4" />
                    <span>{jobData.company}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    <span>{jobData.location}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Briefcase className="h-4 w-4" />
                    <span>{jobData.type}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{jobData.salary}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Badge variant="outline" className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  <span>Posted: {jobData.postedDate}</span>
                </Badge>
                <Badge variant="outline" className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  <span>Deadline: {jobData.deadline}</span>
                </Badge>
              </div>

              <Separator />

              <div>
                <h4 className="font-medium mb-2">Job Description</h4>
                <p className="text-sm text-muted-foreground">{jobData.description}</p>
              </div>

              <div>
                <h4 className="font-medium mb-2">Requirements</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  {jobData.requirements.map((req, index) => (
                    <li key={index}>{req}</li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="font-medium mb-2">Benefits</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  {jobData.benefits.map((benefit, index) => (
                    <li key={index}>{benefit}</li>
                  ))}
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

