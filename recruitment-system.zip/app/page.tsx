import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col items-center justify-center space-y-8 text-center">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl">
            Automated Employee Screening System
          </h1>
          <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
            Streamline your recruitment process with our automated screening and shortlisting system.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-4">
          <Button asChild size="lg">
            <Link href="/login?role=candidate">Candidate Login</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link href="/login?role=admin">Admin Login</Link>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
        <Card>
          <CardHeader>
            <CardTitle>Automated Job Posting</CardTitle>
            <CardDescription>Create and manage job listings efficiently</CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              Easily create job posts with detailed descriptions, requirements, and application deadlines. Manage all
              your job listings from a centralized dashboard.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Secure Screening Tests</CardTitle>
            <CardDescription>Verify candidate identity during tests</CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              Conduct secure screening tests with identity verification through periodic screenshots to ensure test
              integrity and prevent fraud.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Automated Shortlisting</CardTitle>
            <CardDescription>Save time with intelligent candidate selection</CardDescription>
          </CardHeader>
          <CardContent>
            <p>
              Automatically shortlist candidates based on test scores and predefined criteria, with a backup process for
              replacing unavailable candidates.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

