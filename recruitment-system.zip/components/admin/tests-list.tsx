"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, MoreVertical, Eye, AlertCircle, CheckCircle, XCircle, Camera, FileText, Plus } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"

// Sample test data
const testsData = [
  {
    id: 1,
    candidateName: "Sarah Johnson",
    position: "Frontend Developer",
    testDate: "2023-10-18",
    duration: "45 minutes",
    score: 85,
    verificationStatus: "verified",
    status: "completed",
  },
  {
    id: 2,
    candidateName: "Michael Chen",
    position: "UX Designer",
    testDate: "2023-10-17",
    duration: "60 minutes",
    score: 78,
    verificationStatus: "verified",
    status: "completed",
  },
  {
    id: 3,
    candidateName: "Emily Rodriguez",
    position: "Project Manager",
    testDate: "2023-10-16",
    duration: "75 minutes",
    score: 92,
    verificationStatus: "verified",
    status: "completed",
  },
  {
    id: 4,
    candidateName: "David Kim",
    position: "Backend Developer",
    testDate: "2023-10-16",
    duration: "60 minutes",
    score: 81,
    verificationStatus: "flagged",
    status: "completed",
    flagReason: "Identity mismatch detected",
  },
  {
    id: 5,
    candidateName: "Jessica Taylor",
    position: "Marketing Specialist",
    testDate: "Scheduled for 2023-10-25",
    duration: "45 minutes",
    score: null,
    verificationStatus: "pending",
    status: "scheduled",
  },
  {
    id: 6,
    candidateName: "Robert Wilson",
    position: "Data Analyst",
    testDate: "2023-10-14",
    duration: "60 minutes",
    score: 65,
    verificationStatus: "verified",
    status: "completed",
  },
]

export default function AdminTestsList() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredTests, setFilteredTests] = useState(testsData)

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value
    setSearchTerm(term)

    if (term.trim() === "") {
      setFilteredTests(testsData)
    } else {
      const filtered = testsData.filter(
        (test) =>
          test.candidateName.toLowerCase().includes(term.toLowerCase()) ||
          test.position.toLowerCase().includes(term.toLowerCase()),
      )
      setFilteredTests(filtered)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500">Completed</Badge>
      case "scheduled":
        return <Badge variant="outline">Scheduled</Badge>
      case "in-progress":
        return <Badge className="bg-blue-500">In Progress</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getVerificationBadge = (status: string, reason?: string) => {
    switch (status) {
      case "verified":
        return (
          <div className="flex items-center gap-1 text-green-500">
            <CheckCircle className="h-4 w-4" />
            <span className="text-xs">Verified</span>
          </div>
        )
      case "flagged":
        return (
          <div className="flex items-center gap-1 text-amber-500" title={reason}>
            <AlertCircle className="h-4 w-4" />
            <span className="text-xs">Flagged</span>
          </div>
        )
      case "pending":
        return (
          <div className="flex items-center gap-1 text-gray-500">
            <span className="text-xs">Pending</span>
          </div>
        )
      default:
        return <span className="text-xs">{status}</span>
    }
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search tests..." className="pl-8" value={searchTerm} onChange={handleSearch} />
          </div>
          <Button asChild>
            <Link href="/admin/tests/create">
              <Plus className="mr-2 h-4 w-4" />
              Create Test
            </Link>
          </Button>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Candidate</TableHead>
                <TableHead>Position</TableHead>
                <TableHead>Test Date</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Score</TableHead>
                <TableHead>Verification</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTests.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-4">
                    No tests found matching your search.
                  </TableCell>
                </TableRow>
              ) : (
                filteredTests.map((test) => (
                  <TableRow key={test.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={test.candidateName} />
                          <AvatarFallback>
                            {test.candidateName
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{test.candidateName}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{test.position}</TableCell>
                    <TableCell>{test.testDate}</TableCell>
                    <TableCell>{test.duration}</TableCell>
                    <TableCell>
                      {test.score !== null ? (
                        <span className={`font-medium ${test.score >= 70 ? "text-green-600" : "text-red-600"}`}>
                          {test.score}%
                        </span>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>{getVerificationBadge(test.verificationStatus, test.flagReason)}</TableCell>
                    <TableCell>{getStatusBadge(test.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="h-4 w-4" />
                            <span className="sr-only">Actions</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Eye className="mr-2 h-4 w-4" />
                            View Test Details
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <FileText className="mr-2 h-4 w-4" />
                            View Test Results
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Camera className="mr-2 h-4 w-4" />
                            View Verification Screenshots
                          </DropdownMenuItem>
                          {test.verificationStatus === "flagged" && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                                Approve Verification
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <XCircle className="mr-2 h-4 w-4 text-red-500" />
                                Reject Verification
                              </DropdownMenuItem>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

