"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, MoreVertical, FileText, Mail, Calendar, AlertCircle, CheckCircle, XCircle, Eye } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

// Sample candidate data
const candidatesData = [
  {
    id: 1,
    name: "Sarah Johnson",
    email: "sarah.j@example.com",
    position: "Frontend Developer",
    appliedDate: "2023-10-18",
    testStatus: "completed",
    testScore: 85,
    verificationStatus: "verified",
    status: "shortlisted",
  },
  {
    id: 2,
    name: "Michael Chen",
    email: "michael.c@example.com",
    position: "UX Designer",
    appliedDate: "2023-10-17",
    testStatus: "completed",
    testScore: 78,
    verificationStatus: "verified",
    status: "shortlisted",
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    email: "emily.r@example.com",
    position: "Project Manager",
    appliedDate: "2023-10-16",
    testStatus: "completed",
    testScore: 92,
    verificationStatus: "verified",
    status: "interviewing",
  },
  {
    id: 4,
    name: "David Kim",
    email: "david.k@example.com",
    position: "Backend Developer",
    appliedDate: "2023-10-16",
    testStatus: "completed",
    testScore: 81,
    verificationStatus: "flagged",
    status: "reviewing",
  },
  {
    id: 5,
    name: "Jessica Taylor",
    email: "jessica.t@example.com",
    position: "Marketing Specialist",
    appliedDate: "2023-10-15",
    testStatus: "pending",
    testScore: null,
    verificationStatus: "pending",
    status: "applied",
  },
  {
    id: 6,
    name: "Robert Wilson",
    email: "robert.w@example.com",
    position: "Data Analyst",
    appliedDate: "2023-10-14",
    testStatus: "completed",
    testScore: 65,
    verificationStatus: "verified",
    status: "rejected",
  },
]

export default function AdminCandidatesList() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredCandidates, setFilteredCandidates] = useState(candidatesData)

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value
    setSearchTerm(term)

    if (term.trim() === "") {
      setFilteredCandidates(candidatesData)
    } else {
      const filtered = candidatesData.filter(
        (candidate) =>
          candidate.name.toLowerCase().includes(term.toLowerCase()) ||
          candidate.email.toLowerCase().includes(term.toLowerCase()) ||
          candidate.position.toLowerCase().includes(term.toLowerCase()),
      )
      setFilteredCandidates(filtered)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "shortlisted":
        return <Badge className="bg-blue-500">Shortlisted</Badge>
      case "interviewing":
        return <Badge className="bg-purple-500">Interviewing</Badge>
      case "reviewing":
        return <Badge variant="outline">Reviewing</Badge>
      case "applied":
        return <Badge variant="secondary">Applied</Badge>
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getVerificationBadge = (status: string) => {
    switch (status) {
      case "verified":
        return (
          <div className="flex items-center gap-1 text-green-500">
            <CheckCircle className="h-4 w-4" />
            <span className="text-xs">Verified</span>
          </div>
        )
      case "flagged":
        return (
          <div className="flex items-center gap-1 text-amber-500">
            <AlertCircle className="h-4 w-4" />
            <span className="text-xs">Flagged</span>
          </div>
        )
      case "pending":
        return (
          <div className="flex items-center gap-1 text-gray-500">
            <span className="text-xs">Pending</span>
          </div>
        )
      default:
        return <span className="text-xs">{status}</span>
    }
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search candidates..." className="pl-8" value={searchTerm} onChange={handleSearch} />
          </div>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Candidate</TableHead>
                <TableHead>Position</TableHead>
                <TableHead>Applied Date</TableHead>
                <TableHead>Test Status</TableHead>
                <TableHead>Verification</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCandidates.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-4">
                    No candidates found matching your search.
                  </TableCell>
                </TableRow>
              ) : (
                filteredCandidates.map((candidate) => (
                  <TableRow key={candidate.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={candidate.name} />
                          <AvatarFallback>
                            {candidate.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{candidate.name}</p>
                          <p className="text-xs text-muted-foreground">{candidate.email}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{candidate.position}</TableCell>
                    <TableCell>{candidate.appliedDate}</TableCell>
                    <TableCell>
                      {candidate.testStatus === "completed" ? (
                        <div>
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Completed
                          </Badge>
                          <p className="text-xs mt-1">Score: {candidate.testScore}%</p>
                        </div>
                      ) : candidate.testStatus === "pending" ? (
                        <Badge variant="outline">Pending</Badge>
                      ) : (
                        <span>{candidate.testStatus}</span>
                      )}
                    </TableCell>
                    <TableCell>{getVerificationBadge(candidate.verificationStatus)}</TableCell>
                    <TableCell>{getStatusBadge(candidate.status)}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="h-4 w-4" />
                            <span className="sr-only">Actions</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Eye className="mr-2 h-4 w-4" />
                            View Profile
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <FileText className="mr-2 h-4 w-4" />
                            View Test Results
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Mail className="mr-2 h-4 w-4" />
                            Send Email
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Calendar className="mr-2 h-4 w-4" />
                            Schedule Interview
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                            Shortlist Candidate
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <XCircle className="mr-2 h-4 w-4 text-red-500" />
                            Reject Candidate
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

