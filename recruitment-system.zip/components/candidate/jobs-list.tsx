"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, MapPin, Briefcase, Clock, Building, Calendar } from "lucide-react"

// Sample job data
const jobsData = [
  {
    id: 1,
    title: "Frontend Developer",
    company: "TechCorp Inc.",
    location: "Remote",
    type: "Full-time",
    salary: "$80,000 - $100,000",
    postedDate: "2023-10-15",
    deadline: "2023-11-15",
    description:
      "We are looking for a skilled Frontend Developer to join our team. The ideal candidate should have experience with React, TypeScript, and modern CSS frameworks.",
  },
  {
    id: 2,
    title: "UX Designer",
    company: "DesignHub",
    location: "New York, NY",
    type: "Full-time",
    salary: "$75,000 - $95,000",
    postedDate: "2023-10-12",
    deadline: "2023-11-12",
    description:
      "Join our creative team as a UX Designer. You'll be responsible for creating user-centered designs and improving the overall user experience of our products.",
  },
  {
    id: 3,
    title: "Project Manager",
    company: "InnovateTech",
    location: "San Francisco, CA",
    type: "Full-time",
    salary: "$90,000 - $110,000",
    postedDate: "2023-10-10",
    deadline: "2023-11-10",
    description:
      "We're seeking an experienced Project Manager to lead our development teams. The ideal candidate should have a strong technical background and excellent communication skills.",
  },
  {
    id: 4,
    title: "Backend Developer",
    company: "CodeWorks",
    location: "Remote",
    type: "Full-time",
    salary: "$85,000 - $105,000",
    postedDate: "2023-10-08",
    deadline: "2023-11-08",
    description:
      "Looking for a Backend Developer with experience in Node.js, Express, and MongoDB. You'll be working on building scalable APIs and microservices.",
  },
  {
    id: 5,
    title: "Marketing Specialist",
    company: "GrowthLabs",
    location: "Chicago, IL",
    type: "Part-time",
    salary: "$30 - $40 per hour",
    postedDate: "2023-10-05",
    deadline: "2023-11-05",
    description:
      "Join our marketing team to help develop and implement marketing strategies. Experience with digital marketing and analytics is required.",
  },
  {
    id: 6,
    title: "Data Analyst",
    company: "DataInsights",
    location: "Remote",
    type: "Contract",
    salary: "$50 - $60 per hour",
    postedDate: "2023-10-01",
    deadline: "2023-11-01",
    description:
      "We're looking for a Data Analyst to help us make data-driven decisions. Experience with SQL, Python, and data visualization tools is required.",
  },
]

export default function CandidateJobsList() {
  const [searchTerm, setSearchTerm] = useState("")
  const [locationFilter, setLocationFilter] = useState("")
  const [typeFilter, setTypeFilter] = useState("")
  const [filteredJobs, setFilteredJobs] = useState(jobsData)

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value
    setSearchTerm(term)
    applyFilters(term, locationFilter, typeFilter)
  }

  const handleLocationChange = (value: string) => {
    setLocationFilter(value)
    applyFilters(searchTerm, value, typeFilter)
  }

  const handleTypeChange = (value: string) => {
    setTypeFilter(value)
    applyFilters(searchTerm, locationFilter, value)
  }

  const applyFilters = (search: string, location: string, type: string) => {
    let filtered = jobsData

    if (search.trim() !== "") {
      filtered = filtered.filter(
        (job) =>
          job.title.toLowerCase().includes(search.toLowerCase()) ||
          job.company.toLowerCase().includes(search.toLowerCase()) ||
          job.description.toLowerCase().includes(search.toLowerCase()),
      )
    }

    if (location !== "") {
      filtered = filtered.filter((job) => job.location === location)
    }

    if (type !== "") {
      filtered = filtered.filter((job) => job.type === type)
    }

    setFilteredJobs(filtered)
  }

  const uniqueLocations = Array.from(new Set(jobsData.map((job) => job.location)))
  const uniqueTypes = Array.from(new Set(jobsData.map((job) => job.type)))

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search jobs by title, company, or keywords..."
              className="pl-8"
              value={searchTerm}
              onChange={handleSearch}
            />
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <Select value={locationFilter} onValueChange={handleLocationChange}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Locations</SelectItem>
                {uniqueLocations.map((location, index) => (
                  <SelectItem key={index} value={location}>
                    {location}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={handleTypeChange}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Job Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Types</SelectItem>
                {uniqueTypes.map((type, index) => (
                  <SelectItem key={index} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-4">
          {filteredJobs.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No jobs found matching your search criteria.</p>
            </div>
          ) : (
            filteredJobs.map((job) => (
              <div key={job.id} className="border rounded-lg p-6 hover:shadow-md transition-shadow">
                <div className="flex flex-col md:flex-row justify-between gap-4">
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold">{job.title}</h3>
                    <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Building className="h-4 w-4" />
                        <span>{job.company}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        <span>{job.location}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Briefcase className="h-4 w-4" />
                        <span>{job.type}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        <span>{job.salary}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      <span>Deadline: {job.deadline}</span>
                    </Badge>
                  </div>
                </div>
                <p className="mt-4 text-muted-foreground">{job.description}</p>
                <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-end">
                  <Button variant="outline" asChild>
                    <Link href={`/jobs/${job.id}`}>View Details</Link>
                  </Button>
                  <Button asChild>
                    <Link href={`/jobs/${job.id}/apply`}>Apply Now</Link>
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}

