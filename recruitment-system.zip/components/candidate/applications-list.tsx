"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, FileText, Eye, Calendar, Building, Clock } from "lucide-react"

// Sample application data
const applicationsData = [
  {
    id: 1,
    jobTitle: "Frontend Developer",
    company: "TechCorp Inc.",
    appliedDate: "2023-10-18",
    testDate: "2023-10-25",
    testStatus: "scheduled",
    applicationStatus: "under review",
  },
  {
    id: 2,
    jobTitle: "UX Designer",
    company: "DesignHub",
    appliedDate: "2023-10-17",
    testDate: "2023-10-28",
    testStatus: "scheduled",
    applicationStatus: "under review",
  },
  {
    id: 3,
    jobTitle: "Project Manager",
    company: "InnovateTech",
    appliedDate: "2023-10-10",
    testDate: "2023-10-15",
    testStatus: "completed",
    testScore: 92,
    applicationStatus: "shortlisted",
  },
  {
    id: 4,
    jobTitle: "Backend Developer",
    company: "CodeWorks",
    appliedDate: "2023-10-05",
    testDate: "2023-10-12",
    testStatus: "completed",
    testScore: 78,
    applicationStatus: "interviewing",
    interviewDate: "2023-10-25",
  },
  {
    id: 5,
    jobTitle: "Marketing Specialist",
    company: "GrowthLabs",
    appliedDate: "2023-09-28",
    testDate: "2023-10-05",
    testStatus: "completed",
    testScore: 65,
    applicationStatus: "rejected",
  },
]

export default function CandidateApplicationsList() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredApplications, setFilteredApplications] = useState(applicationsData)

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value
    setSearchTerm(term)

    if (term.trim() === "") {
      setFilteredApplications(applicationsData)
    } else {
      const filtered = applicationsData.filter(
        (application) =>
          application.jobTitle.toLowerCase().includes(term.toLowerCase()) ||
          application.company.toLowerCase().includes(term.toLowerCase()),
      )
      setFilteredApplications(filtered)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "under review":
        return <Badge variant="outline">Under Review</Badge>
      case "shortlisted":
        return <Badge className="bg-blue-500">Shortlisted</Badge>
      case "interviewing":
        return <Badge className="bg-purple-500">Interviewing</Badge>
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>
      case "hired":
        return <Badge className="bg-green-500">Hired</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getTestStatusBadge = (status: string) => {
    switch (status) {
      case "scheduled":
        return <Badge variant="outline">Scheduled</Badge>
      case "completed":
        return <Badge className="bg-green-500">Completed</Badge>
      case "pending":
        return <Badge variant="secondary">Pending</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search applications..." className="pl-8" value={searchTerm} onChange={handleSearch} />
          </div>
        </div>

        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Job</TableHead>
                <TableHead>Applied Date</TableHead>
                <TableHead>Test Status</TableHead>
                <TableHead>Application Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredApplications.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-4">
                    No applications found matching your search.
                  </TableCell>
                </TableRow>
              ) : (
                filteredApplications.map((application) => (
                  <TableRow key={application.id}>
                    <TableCell>
                      <div className="space-y-1">
                        <p className="font-medium">{application.jobTitle}</p>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Building className="mr-1 h-3 w-3" />
                          {application.company}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{application.appliedDate}</TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        {getTestStatusBadge(application.testStatus)}
                        {application.testStatus === "scheduled" ? (
                          <div className="flex items-center text-xs text-muted-foreground mt-1">
                            <Calendar className="mr-1 h-3 w-3" />
                            {application.testDate}
                          </div>
                        ) : application.testStatus === "completed" ? (
                          <div className="text-xs mt-1">
                            Score:{" "}
                            <span className={application.testScore >= 70 ? "text-green-600" : "text-red-600"}>
                              {application.testScore}%
                            </span>
                          </div>
                        ) : null}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        {getStatusBadge(application.applicationStatus)}
                        {application.applicationStatus === "interviewing" && application.interviewDate && (
                          <div className="flex items-center text-xs text-muted-foreground mt-1">
                            <Clock className="mr-1 h-3 w-3" />
                            Interview: {application.interviewDate}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/applications/${application.id}`}>
                            <Eye className="mr-2 h-4 w-4" />
                            Details
                          </Link>
                        </Button>
                        {application.testStatus === "scheduled" && (
                          <Button size="sm" asChild>
                            <Link href={`/tests/${application.id}`}>
                              <FileText className="mr-2 h-4 w-4" />
                              Take Test
                            </Link>
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

